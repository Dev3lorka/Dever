DEV3LORKA CUSTOM PACK — MINECRAFT JAVA 1.21.4

IMPORTANT: This resource pack does NOT magically change a normal item.
The item must receive the minecraft:item_model component.

HEADS / HELMETS
01 player_head
02 zombie_head
03 creeper_head
04 skeleton_skull
05 wither_skeleton_skull
06 piglin_head
07 dragon_head
08 carved_pumpkin
09 jack_o_lantern
10 leather_helmet
11 iron_helmet
12 golden_helmet
13 diamond_helmet
14 chainmail_helmet

CUSTOM ITEMS
01 heart_of_the_sea = zamek z piasku texture
02 disc_fragment_5 = lod na patyku texture
03 potion (water) = kokos texture
04 snowball = pilka texture

TEST COMMANDS — run in Minecraft 1.21.4 after loading this pack:
/give @p minecraft:player_head[item_model="customskins:head_01"]
/give @p minecraft:zombie_head[item_model="customskins:head_02"]
/give @p minecraft:creeper_head[item_model="customskins:head_03"]
/give @p minecraft:skeleton_skull[item_model="customskins:head_04"]
/give @p minecraft:wither_skeleton_skull[item_model="customskins:head_05"]
/give @p minecraft:piglin_head[item_model="customskins:head_06"]
/give @p minecraft:dragon_head[item_model="customskins:head_07"]
/give @p minecraft:carved_pumpkin[item_model="customskins:head_08"]
/give @p minecraft:jack_o_lantern[item_model="customskins:head_09"]
/give @p minecraft:leather_helmet[item_model="customskins:head_10"]
/give @p minecraft:iron_helmet[item_model="customskins:head_11"]
/give @p minecraft:golden_helmet[item_model="customskins:head_12"]
/give @p minecraft:diamond_helmet[item_model="customskins:head_13"]
/give @p minecraft:chainmail_helmet[item_model="customskins:head_14"]
/give @p minecraft:heart_of_the_sea[item_model="customskins:custom_01"]
/give @p minecraft:disc_fragment_5[item_model="customskins:custom_02"]
/give @p minecraft:potion[potion="minecraft:water",item_model="customskins:custom_03"]
/give @p minecraft:snowball[item_model="customskins:custom_04"]

The .txt list is only instructions; Minecraft does not execute a .txt file.


AUTO CUSTOM ITEMS — added in v2
The 4 special custom items now activate automatically by base item type:
- heart_of_the_sea -> sandcastle
- disc_fragment_5 -> ice on a stick
- potion -> coconut
- snowball -> ball

IMPORTANT: because Minecraft 1.21.4 cannot select a potion variant by potion_contents in the item-model definition,
the automatic potion definition applies to ALL potion variants. If you want only WATER potion to become the coconut,
use the provided item_model command instead:
 /give @p minecraft:potion[potion="minecraft:water",item_model="customskins:custom_03"]


v3 HEAD FIX
Custom heads now use the custom item model when display_context=head, with a head-slot display transform. This is the important part that makes the custom head visible when worn instead of falling back to the Steve/Alex skull texture.
