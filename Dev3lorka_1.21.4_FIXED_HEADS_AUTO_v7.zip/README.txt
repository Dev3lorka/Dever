DEV3LORKA CUSTOM PACK — AUTO_v7 — MINECRAFT JAVA 1.21.4

WHAT IS FIXED
- Based on the known-working AUTO_v4 head setup.
- Head/helmet display models are preserved so equipped heads remain visible to the wearer and other players.
- Four special item textures have their brown screenshot/background removed and transparency preserved.
- Sandcastle = heart_of_the_sea
- Ice on a stick = disc_fragment_5
- Ball = snowball
- Coconut = WATER POTION ONLY via the command below.

IMPORTANT: WATER-ONLY COCONUT
Minecraft 1.21.4 resource-pack item definitions cannot select the potion variant
(water vs other potion) by potion contents in the same way later item-model features can.
Therefore the normal potion item remains vanilla in this pack.

Use this exact command for the coconut:
 /give @p minecraft:potion[potion="minecraft:water",item_model="customskins:custom_03"]

Do NOT replace assets/minecraft/items/potion.json with custom_03 globally,
otherwise every potion becomes the coconut.

SPECIAL ITEMS (automatic by base item)
 /give @p minecraft:heart_of_the_sea
 /give @p minecraft:disc_fragment_5
 /give @p minecraft:snowball

HEAD EXAMPLES
 /give @p minecraft:player_head[item_model="customskins:head_01"]
 /give @p minecraft:zombie_head[item_model="customskins:head_02"]
 /give @p minecraft:creeper_head[item_model="customskins:head_03"]
 /give @p minecraft:skeleton_skull[item_model="customskins:head_04"]
 /give @p minecraft:wither_skeleton_skull[item_model="customskins:head_05"]
 /give @p minecraft:piglin_head[item_model="customskins:head_06"]
 /give @p minecraft:dragon_head[item_model="customskins:head_07"]
 /give @p minecraft:carved_pumpkin[item_model="customskins:head_08"]
 /give @p minecraft:jack_o_lantern[item_model="customskins:head_09"]
 /give @p minecraft:leather_helmet[item_model="customskins:head_10"]
 /give @p minecraft:iron_helmet[item_model="customskins:head_11"]
 /give @p minecraft:golden_helmet[item_model="customskins:head_12"]
 /give @p minecraft:diamond_helmet[item_model="customskins:head_13"]
 /give @p minecraft:chainmail_helmet[item_model="customskins:head_14"]
