DEV3LORKA CUSTOM PACK — AUTO_v8 — Minecraft Java 1.21.4

V8 = wersja z automatycznym przypisaniem 14 główek/helmów.
Nie trzeba dodawać item_model do komendy dla tych 14 typów — paczka sama podmienia ich model.

AUTOMATYCZNE GŁÓWKI:
player_head        -> head_01
zombie_head        -> head_02
creeper_head       -> head_03
skeleton_skull     -> head_04
wither_skeleton_skull -> head_05
piglin_head        -> head_06
dragon_head        -> head_07
carved_pumpkin     -> head_08
jack_o_lantern     -> head_09
leather_helmet     -> head_10
iron_helmet        -> head_11
golden_helmet      -> head_12
diamond_helmet     -> head_13
chainmail_helmet   -> head_14

Najważniejsze:
- Główki zachowują przezroczystość — brak szarego/brązowego tła.
- Model jest ustawiony również dla kontekstu HEAD, więc założona główka jest widoczna na graczu.
- Inni gracze też powinni widzieć ten sam model, jeśli mają pobraną tę samą paczkę.
- 4 specjalne itemy pozostają bez tła:
  heart_of_the_sea -> zamek z piasku
  disc_fragment_5  -> lód na patyku
  snowball         -> piłka
  potion           -> kokos tylko przez komendę poniżej

KOKOS — TYLKO ZWYKŁA WODA:
 /give @s minecraft:potion[potion="minecraft:water",item_model="customskins:custom_03"]

Nie zmieniamy globalnie wszystkich potionów na kokos, więc inne potki pozostają normalne.

SPECJALNE ITEMY:
 /give @s minecraft:heart_of_the_sea
 /give @s minecraft:disc_fragment_5
 /give @s minecraft:snowball

Po podmianie paczki na serwerze zrestartuj serwer i klienta Minecraft albo wykonaj F3+T.
