DEV3LORKA CUSTOM PACK — MINECRAFT JAVA 1.21.4
AUTO_v5

HEADS
- AUTO_v4 head system is preserved unchanged.
- Custom heads remain visible when equipped and to other players.
- Head textures keep transparency; no grey UI background is added.

CUSTOM ITEMS
01 heart_of_the_sea = zamek z piasku
02 disc_fragment_5 = lod na patyku
03 potion (WATER ONLY) = kokos
04 snowball = pilka

AUTOMATIC ITEMS
- heart_of_the_sea -> customskins:custom_01
- disc_fragment_5 -> customskins:custom_02
- snowball -> customskins:custom_04

WATER POTION
Minecraft 1.21.4's vanilla item-model definitions cannot safely distinguish
the water potion from every other potion variant without changing the item
component. Therefore potion.json is kept vanilla so normal potions stay normal.

Use this command for the coconut water potion:
 /give @p minecraft:potion[potion="minecraft:water",item_model="customskins:custom_03"]

The four custom item textures are PNGs with transparent backgrounds.
No grey inventory background is part of the textures.
