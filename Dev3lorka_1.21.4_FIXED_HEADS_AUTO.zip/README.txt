DEV3LORKA CUSTOM PACK — MINECRAFT JAVA 1.21.4

AUTOMATIC HEADS
No item_model component is required for the 14 heads/helmets.
Just give the normal vanilla item:

/give @p minecraft:player_head
/give @p minecraft:zombie_head
/give @p minecraft:creeper_head
/give @p minecraft:skeleton_skull
/give @p minecraft:wither_skeleton_skull
/give @p minecraft:piglin_head
/give @p minecraft:dragon_head
/give @p minecraft:carved_pumpkin
/give @p minecraft:jack_o_lantern
/give @p minecraft:leather_helmet
/give @p minecraft:iron_helmet
/give @p minecraft:golden_helmet
/give @p minecraft:diamond_helmet
/give @p minecraft:chainmail_helmet

The resource pack maps each vanilla item automatically to its custom head.
When equipped on the player's head, the custom head texture is used.

The existing 4 custom item models were preserved unchanged.
