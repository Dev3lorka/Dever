DEV3LORKA CUSTOM PACK — AUTO_v6 — MINECRAFT JAVA 1.21.4

HEADS
- Based directly on the known-working AUTO_v4.
- Head item models remain visible in the head display context and to other players.
- Transparent PNGs are preserved; no grey background is included.

FOUR SPECIAL ITEMS
1. heart_of_the_sea -> zamek z piasku
2. disc_fragment_5 -> lod na patyku
3. potion (WATER ONLY) -> kokos
4. snowball -> pilka

IMPORTANT — COCONUT
Minecraft 1.21.4 cannot distinguish the potion variant (water vs other potion) in an item-model definition using only the resource pack. Therefore potion.json intentionally keeps normal vanilla potion rendering.

Use this exact command for the coconut water potion:
/give @p minecraft:potion[potion="minecraft:water",item_model="customskins:custom_03"]

The other three special items are automatic through assets/minecraft/items.
Do not replace potion.json with custom_03 globally, otherwise every potion becomes the coconut.
